import os 

template = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Workshop Nhiếp Ảnh</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container {
            width: 700px;
            margin: 40px auto;
            text-align: center;
        }

        .club-name {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .top-bar {
            background-color: #074596;
            height: 50px;
            display: flex;
            align-items: center;
            padding-left: 15px;
        }

        .dot {
            width: 14px;
            height: 14px;
            background-color: white;
            border-radius: 50%;
            margin-right: 8px;
        }

        .content {
            background-color: #a7d0ff;
            color: rgb(25, 54, 112);
            text-align: left;
            padding: 40px;
        }

        .headline {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .circles {
            margin-bottom: 25px;
        }

        .circle {
            width: 16px;
            height: 16px;
            border: 2px solid white;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }

        .line {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .footer {
            text-align: left;
            margin-top: 30px;
            font-size: 16px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="club-name">CLB NHIẾP ẢNH TRẺ</div>

        <div class="top-bar">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>

        <div class="content">
            <div class="headline">WORKSHOP CHỤP ẢNH</div>

            <div class="circles">
                <span class="circle"></span>
                <span class="circle"></span>
                <span class="circle"></span>
                <span class="circle"></span>
                <span class="circle"></span>
            </div>

            <div class="line">• Hướng dẫn chụp ảnh từ cơ bản đến nâng cao</div>
            <div class="line">• Thực hành trực tiếp với giảng viên</div>
            <div class="line">• Phù hợp cho người mới bắt đầu</div>
            <div class="line">• Nhận chứng nhận sau buổi học</div>
        </div>

        <div class="footer">
            <div><strong>Thời gian:</strong> 20/10/2026</div>
            <div><strong>Địa điểm:</strong> Nhà Văn hoá Thanh Niên</div>
            <div><strong>Website:</strong> www.photoclub.vn</div>
        </div>
    </div>

</body>
</html>



"""

os.makedirs("Final_project/poster_templates/html_templates")
with open("Final_project/poster_templates/html_templates/poster.html", "w", encoding="utf-8") as f:
    f.write(template)
    print("Save as html file done!")

os.makedirs("Final_project/poster_templates/plain_text")
with open("Final_project/poster_templates/plain_text/poster.txt", "w", encoding="utf-8") as f:
    f.write(template)
    print("Save as text file done!")