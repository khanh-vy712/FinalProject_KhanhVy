import os 

template = """
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Chúc mừng sinh nhật</title>
</head>

<body style="margin:0; padding:0; background-color:#FFF8F1; font-family: 'Open Sans', 'Roboto', Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center">

        <!-- Container -->
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff; margin:20px 0; border-radius:6px; overflow:hidden;">

          <!-- Header -->
          <tr>
            <td style="padding:20px; text-align:center; border-bottom:3px solid #6CAFA8;">
              <h1 style="margin:0; color:#333333; font-size:24px;">Thư từ VietnamWorks!</h1>
            </td>
          </tr>

          <!-- Content -->
          <tr>
            <td style="padding:30px; color:#333333; line-height:1.6;">
              <p style="font-size:16px;">Xin chào <strong>{{name}}</strong>,</p>

              <p>
                Hôm nay là một ngày đặc biệt 🎉  
                Thay vì gửi thông báo công việc, chúng tôi muốn gửi lời
                <strong style="color:#c0b752;">CHÚC MỪNG SINH NHẬT</strong> đến bạn.
              </p>

              <p>
                Cầu chúc bạn một năm tuyệt vời với nhiều cơ hội, thành công
                và những trải nghiệm đáng nhớ trong cuộc sống 🌟
              </p>

              <p>
                <strong>VietnamWorks</strong> – Chúng tôi là <span style="color:#3b82f6;">nhịp cầu</span>
                giúp bạn đạt được giấc mơ nghề nghiệp và phát triển bản thân.
              </p>
            </td>
          </tr>

          <!-- Birthday Image -->
          <tr>
            <td align="center" style="padding:20px;">
              <img src="https://i.pinimg.com/1200x/4f/82/cd/4f82cdfd28318bb9185ee682bf7bbb47.jpg"
                   alt="Happy Birthday"
                   width="600"
                   height="400"
                   style="display:block;">
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f1f5f9; padding:15px; text-align:center; font-size:12px; color:#666;">
              © 2026 VietnamWorks. All rights reserved.
            </td>
          </tr>

        </table>
        <!-- End Container -->

      </td>
    </tr>
  </table>
</body>
</html>


"""

os.makedirs("Final_project/hpbd_templates/html_templates")
with open("Final_project/hpbd_templates/html_templates/hpbd.html", "w", encoding="utf-8") as f:
    f.write(template)
    print("Save as html file done!")

os.makedirs("Final_project/hpbd_templates/plain_text")
with open("Final_project/hpbd_templates/plain_text/hpbd.txt", "w", encoding="utf-8") as f:
    f.write(template)
    print("Save as text file done!")