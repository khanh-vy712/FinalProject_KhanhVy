import smtplib
from dotenv import load_dotenv

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import json
from jinja2 import Template

load_dotenv()

template_str = open("D:\\Modul3_Level2\\Final_project\\bangdiem_templates\\html_templates\\bangdiem.html", "r", encoding="utf-8").read()
template = Template(template_str)

def load_user(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        print("Không có file JSON")
        return[]

receiver_data = load_user("D:\\Modul3_Level2\\Final_project\\student_data.json")

sender = os.getenv("FROM_EMAIL")
password = os.getenv("APP_PASSWORD")
subject = os.getenv("SUBJECT")

if receiver_data:
    for load_data in receiver_data:
        # Normalize data keys to match the template variables
        context = dict(load_data)  # shallow copy

        # Map common key names the template expects
        context.setdefault('student_name', load_data.get('name') or load_data.get('student_name'))
        context.setdefault('class_name', load_data.get('class_name'))
        context.setdefault('teacher_name', load_data.get('teacher') or load_data.get('teacher_name'))
        context.setdefault('report_date', load_data.get('report_date'))
        context.setdefault('school_name', load_data.get('school') or load_data.get('school_name'))
        context.setdefault('details_link', load_data.get('link') or load_data.get('details_link'))
        context.setdefault('school_address', load_data.get('school_address') or "Chưa cập nhật địa chỉ trường")

        # Convert scores dict -> grades list expected by the template
        scores = load_data.get('scores') or {}
        grades = []
        if isinstance(scores, dict):
            for subj, vals in scores.items():
                grades.append({
                    'subject': subj,
                    'mid_term': vals.get('mid_term') if isinstance(vals, dict) else None,
                    'final': vals.get('final') if isinstance(vals, dict) else None,
                    'average': vals.get('average') if isinstance(vals, dict) else None,
                    'comment': vals.get('comment') if isinstance(vals, dict) else ''
                })
        context['grades'] = grades
        context.setdefault('gpa', load_data.get('gpa'))
        context.setdefault('advice', load_data.get('remark') or load_data.get('advice'))

        email_html_content = template.render(**context)
        receiver = load_data.get("email") or load_data.get("parent_email")
        if not receiver:
            print("⚠ Bỏ qua: bản ghi thiếu địa chỉ email, tiếp tục.")
            continue

        msg = MIMEMultipart("alternative")
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = receiver

        part_html = MIMEText(email_html_content, "html", "utf-8")
        msg.attach(part_html)

        try:
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.starttls()
                server.login(sender, password)
                server.sendmail(sender, receiver, msg.as_string())
                print(f"✅ Gửi email thành công đến: {receiver}")
        except Exception as e:
            print(f"❌ Không thể gửi email đến {receiver}: {e}")
else:
    print("Không có dữ liệu người nhận để gửi email")